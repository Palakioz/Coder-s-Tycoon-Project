import React from "react";

const Courses = () => {
  return (
    <div>
      <h1>Home</h1>
    </div>
  );
};

export default Courses;
